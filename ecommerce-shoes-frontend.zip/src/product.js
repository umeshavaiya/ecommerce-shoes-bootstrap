const product = [{
    _id: '1',
    name: 'boat Airdopes 121v2 TWS Earbuds',
    image: '/images/orange.png',
    description: 'boAt Airdopes 121v2 TWS Earbuds with Bluetooth v5.0, Immersive Audio, Up to 14H Total Playback, Instant Voice Ass',
    brand: 'Boat',
    category: 'Electronics',
    price: 20.99,
    countInStock: 10,
    rating: 4.5,
    numReviews: 12
}, {
    _id: '2',
    name: 'Micromax IN 1b (Purple, 32 GB)',
    image: '/images/mensblue.png',
    description: 'Say hello to the Micromax IN 1b smartphone whose powerful MediaTek Helio G35 gaming processor and a 5000 mAh batt',
    brand: 'Micromax',
    category: 'Electronics',
    price: 599.99,
    countInStock: 7,
    rating: 4.0,
    numReviews: 8,
}]

export default product;