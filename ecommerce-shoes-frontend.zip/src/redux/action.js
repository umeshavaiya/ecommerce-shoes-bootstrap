import * as types from './actionType';
import { auth, googleAuthProvider } from '../firebase'
import axios from 'axios';

// For user register
const registerStart = () => ({
    type: types.REGISTER_START
});
const registerSuccess = (user) => ({
    type: types.REGISTER_SUCCESS,
    payload: user
});
const registerFail = (error) => ({
    type: types.REGISTER_FAIL,
    payload: error
});

// For user login
const loginStart = () => ({
    type: types.LOGIN_START
});
const loginSuccess = (user) => ({
    type: types.LOGIN_SUCCESS,
    payload: user
});
const loginFail = (error) => ({
    type: types.LOGIN_FAIL,
    payload: error
});

// For Google LogIn
const googleSignInStart = () => ({
    type: types.GOOGLE_SIGN_IN_START
});
const googleSignInSuccess = (user) => ({
    type: types.GOOGLE_SIGN_IN_SUCCESS,
    payload: user
});
const googleSignInFail = (error) => ({
    type: types.GOOGLE_SIGN_IN_FAIL,
    payload: error
});

// Fot user Logout
const forLogOut = (user) => ({
    type: types.USER_LOGOUT,
    payload: null
});

export const registerInitiate = (email, password, displayName) => {
    return function (dispatch) {
        dispatch(registerStart())
        auth
            .createUserWithEmailAndPassword(email, password)
            .then(({ user }) => {
                user.updateProfile({
                    displayName,
                });
                dispatch(registerSuccess(user));
            }).catch((error) => dispatch(registerFail(error.message)))
    }
}

export const logoutUser = () => {
    return function (dispatch) {
        auth.signOut()
            .then(() => {
                dispatch(forLogOut())
            })
    }
}
export const loginInitiate = (email, password) => {
    return function (dispatch) {
        dispatch(loginStart())
        auth
            .signInWithEmailAndPassword(email, password)
            .then(({ user }) => {
                dispatch(loginSuccess(user));
            }).catch(() => dispatch(loginFail(alert('Email Address or Password Incorrect'))))
    }
}

export const googleSignInInitiate = () => {
    return function (dispatch) {
        dispatch(googleSignInStart())
        auth
            .signInWithPopup(googleAuthProvider)
            .then(({ user }) => {
                dispatch(googleSignInSuccess(user));
            }).catch((error) => dispatch(googleSignInFail(error.message)))
    }
}

export const listProducts = () => async (dispatch) => {
    try {
        dispatch({ type: types.PRODUCT_LIST_REQUEST })
        const { data } = await axios.get('/api/products')
        dispatch({
            type: types.PRODUCT_LIST_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: types.PRODUCT_LIST_FAILS,
            payload:
                error.response && error.response.data.message
                    ? error.response.data.message
                    : error.message,
        });
    }
};

export const listProductsDetails = (id) => async (dispatch) => {
    try {
        dispatch({ type: types.PRODUCT_DETAILS_REQUEST })
        const { data } = await axios.get(`/api/products/${id}`)
        dispatch({
            type: types.PRODUCT_DETAILS_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: types.PRODUCT_DETAILS_FAILS,
            payload:
                error.response && error.response.data.message
                    ? error.response.data.message
                    : error.message,
        })
    }
}

export const addToCart = (id, qty) => async (dispatch, getState) => {
    const { data } = await axios.get(`/api/products/${id}`)
    dispatch({
        type: types.CART_ADD_ITEM,
        payload: {
            product: data._id,
            name: data.name,
            image: data.image,
            price: data.price,
            countInStock: data.countInStock,
            qty
        }
    })

    localStorage.setItem('cartItems', JSON.stringify(getState().cart.cartItem));
}


export const removeFromCart = (id) => (dispatch, getState) => {
    dispatch({
        type: types.CART_REMOVE_ITEM,
        payload: id
    })

    localStorage.setItem('cartItems', JSON.stringify(getState().cart.cartItems));

}
