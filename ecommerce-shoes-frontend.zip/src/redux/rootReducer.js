import { combineReducers } from "redux";
import userReducer from "./reducer";
import { productListReducer, productDetailsReducer } from "./productReducer";
import { cartReducer } from "./cartReducer"


const rootReducer = combineReducers({
    user: userReducer,
    productList: productListReducer,
    productDetails: productDetailsReducer,
    cart: cartReducer,

})

export default rootReducer;