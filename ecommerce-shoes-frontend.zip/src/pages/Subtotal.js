// import React from 'react'

// function Subtotal() {
//   return (
//     <div className="subtotal">

//       <button>Proceed to Checkout</button>
//     </div>
//   )
// }

// export default Subtotal
