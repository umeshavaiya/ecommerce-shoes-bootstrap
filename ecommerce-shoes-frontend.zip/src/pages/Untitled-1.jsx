// return (props.trigger) ? (
    // return (
    //     <div className="popup">
    //         <div className="popup-inner">
    //             <div className="login">
    //                 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossOrigin="anonymous" />
    //                 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossOrigin="anonymous" referrerPolicy="no-referrer" />
    //                 {/* <Link to='/'>
    //                 <img className="login__logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/1024px-Amazon_logo.svg.png" alt="/" />
    //                 </Link> */}
    //                 <div id="logreg-forms">
    //                     <form id='form-signin' onSubmit={handleSubmit}>
    //                         <h1 className='h3 mb-3 font-weight-normal' style={{ textAlign: "center" }}>
    //                             Sign In
    //                         </h1>
    //                         <div className="social-login">
    //                             <button className='btn google-btn social-btn' type='button' onClick={handleGoogleSignIn}>
    //                                 <span>
    //                                     <i className="fab fa-google-plus-g"></i>  Google+
    //                                 </span>
    //                             </button>
    //                         </div>
    //                         <p style={{ textAlign: 'center' }}>OR</p>
    //                         <input
    //                             type="email"
    //                             id="inputEmail"
    //                             className="form-control"
    //                             placeholder="Email Address"
    //                             name="email"
    //                             onChange={handleChange}
    //                             value={email}
    //                             required
    //                         />

    //                         <input
    //                             type="password"
    //                             id="inputPassword"
    //                             className="form-control"
    //                             placeholder="Password"
    //                             name="password"
    //                             onChange={handleChange}
    //                             value={password}
    //                             required
    //                         />
    //                         <button className='btn btn-secondary btn-block' type='submit'>
    //                             <i className="fas fa-sign-in-alt"></i> Sign In
    //                         </button>
    //                         <hr />
    //                         <p>Don't have Acoount</p>
    //                         <Link to='/register'>
    //                             <button className='btn btn-primary btn-block' type='button' id="btn-">
    //                                 <i className="fas fa-user-plus"></i>  Create your Amazon Account
    //                             </button>
    //                         </Link>

    //                     </form>
    //                 </div>
    //             </div>
    //         </div>
    //     </div >
    // )
    // ) : "";

